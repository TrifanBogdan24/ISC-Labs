#!/usr/bin/python3

import crypt


password = "TODO" # TODO(1)
salt = "TODO" # TODO(2)
hash = "TODO" # TODO(3)

print(hash)
